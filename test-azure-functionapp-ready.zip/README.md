# Azure Function App
Sample Node.js Azure Function.
