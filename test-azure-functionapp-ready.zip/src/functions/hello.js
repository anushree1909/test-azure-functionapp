const { app } = require('@azure/functions');

app.http('hello', {
  methods: ['GET','POST'],
  authLevel: 'anonymous',
  handler: async (request, context) => {
    const name = request.query.get('name') || (await request.text()) || 'Azure User';
    return {
      status: 200,
      body: `Hello ${name}! Azure Function is working.`
    };
  }
});
