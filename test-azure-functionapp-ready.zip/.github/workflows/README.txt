After connecting Deployment Center, Azure will generate the workflow YAML here.
