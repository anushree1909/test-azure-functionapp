module.exports = async function (context, req) {
 const name=req.query.name||(req.body&&req.body.name)||"Azure User";
 context.res={status:200,body:{message:`Hello ${name}`,status:"Function is working!"}};
};