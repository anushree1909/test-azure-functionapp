import azure.functions as func
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    name=req.params.get("name")
    if not name:
        try:
            name=req.get_json().get("name")
        except:
            pass
    if not name:
        name="Azure User"
    return func.HttpResponse(
        json.dumps({"message":f"Hello {name}","status":"Function is working!"}),
        mimetype="application/json",
        status_code=200
    )
